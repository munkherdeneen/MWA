"This is Week2 project for MWA JobSearch application"

"I have spent whole day around 12 hours to work on assignment JobSearch Project".
"I started with 0 project and tried to push myself to code from 0"
"For back-end spent around 7 hours to complete the application. Back-end is completed."
For front-end spent around 3 hours but not completed yet. Some features are still ongoing.